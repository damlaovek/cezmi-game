package domain.playerdata;

/**
 * The Class DataPlayer2.
 */
public class DataPlayer2 extends ADataPlayer {
	
	/**
	 * Instantiates a new data player 2.
	 */
	public DataPlayer2(){
		super();
	}
}
