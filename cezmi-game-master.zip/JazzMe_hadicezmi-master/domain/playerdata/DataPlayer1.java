package domain.playerdata;

/**
 * The Class DataPlayer1.
 */
public class DataPlayer1 extends ADataPlayer {
	
	/**
	 * Instantiates a new data player 1.
	 */
	public DataPlayer1(){
	super();		
	}
}
