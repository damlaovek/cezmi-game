package domain.item;

/**
 * The Class AEngineItem.
 */
public abstract class AEngineItem {
	
	/** The x. */
	protected int x;
	
	/** The y. */
	protected int y;
	
	/** The l. */
	protected int L;
}
