package ui.item;

import java.awt.Graphics;

/**
 * The Interface IUIItem.
 */
public interface IUIItem {
	
	/**
	 * Paint.
	 *
	 * @param g the g
	 */
	public void paint(Graphics g);

}
